package imgur

const (
	apiEndpoint                    = "https://api.imgur.com/3/"
	apiEndpointRapidAPI            = "https://imgur-apiv3.p.rapidapi.com/3/"
	apiEndpointGenerateAccessToken = "https://api.imgur.com/oauth2/token"
)
